%%% This code runs the dynare codes for Carvalho, Covarrubias and Nuño (2022)
clear; 
clearvars -global;    
clc; 

%% Add paths (must be first to access utility functions)
addpath('calibration');
addpath('steady_state');
addpath('dynare');
addpath('utils');
addpath('plotting');

%% Verify required data files exist
required_files = {'calibration_data.mat', 'TFP_process.mat'};
missing_files = {};
for i = 1:numel(required_files)
    if ~exist(required_files{i}, 'file')
        missing_files{end+1} = required_files{i}; %#ok<SAGROW>
    end
end
if ~isempty(missing_files)
    error('main_IRs:MissingDataFiles', ...
        ['Missing required data files: %s\n' ...
         'Please ensure these files are in the MATLAB path or current directory.'], ...
        strjoin(missing_files, ', '));
end

%% Create output folder if it doesn't exist
if ~exist('output', 'dir')
    mkdir('output');
    disp('Created output/ folder');
end

%% Configuration
config = struct();
config.save_results = false;       % Save data and graphs
config.recalibrate = true;         % Recalibrate steady state (false = load saved)
config.compute_all_sectors = false; % true = all 37 sectors, false = specified sectors
config.big_sector_ind = false;     % Only used when compute_all_sectors = false

% Experiment labels
config.date = "_December_2025";
config.exp_label = "_nonlinear_Min";

% IR settings
config.ir_length = 60;

% Target elasticities of substitution
config.sigma_c = 0.5;
config.sigma_m = 0.01;
config.sigma_q = 0.5;
config.sigma_y = 0.8;
config.sigma_I = 0.5;
config.sigma_l = 0.1;

%% Derived settings
N_SECTORS = 37;  % Model constant

if config.compute_all_sectors
    sector_indices = 1:N_SECTORS;
elseif config.big_sector_ind
    sector_indices = [20, 24];
else
    sector_indices = [1];
end

% Validate sector indices
validate_sector_indices(sector_indices, N_SECTORS, 'main_IRs');

save_label = strcat(config.date, config.exp_label);
disp(['Experiment: ' save_label]);
disp(['Sectors: ' num2str(sector_indices)]);

%% Initialize params
params = struct();
params.beta = 0.96;
params.eps_l = 0.5;
params.eps_c = 0.33;
params.theta = 1;
params.IRshock = 0.2231;
params.simul_T = 200;
params.phi = 4;

%% Load calibration data
[calib_data, params] = load_calibration_data(params, sector_indices);
labels = calib_data.labels;
disp('*** LOADED CALIBRATION DATA ***');

%% Steady State Calibration
if config.recalibrate
    params.sigma_c = config.sigma_c;
    params.sigma_m = config.sigma_m;
    params.sigma_q = config.sigma_q;
    params.sigma_y = config.sigma_y;
    params.sigma_I = config.sigma_I;
    params.sigma_l = config.sigma_l;
    
    calib_opts = struct();
    calib_opts.gridpoints = 8;
    calib_opts.verbose = true;
    calib_opts.sol_guess_file = 'SS_CDsolution_norm_permanent.mat';
    calib_opts.fsolve_options = optimset('Display','iter','TolX',1e-10,'TolFun',1e-10,...
        'MaxFunEvals',10000000,'MaxIter',10000);
    
    tic;
    [ModData, params] = calibrate_steady_state(params, calib_opts);
    fprintf('Calibration time: %.2f seconds.\n', toc);
    
    save('calibrated_steady_state.mat', 'ModData', 'params');
    disp('*** SAVED STEADY STATE ***');
else
    load('calibrated_steady_state.mat', 'ModData', 'params');
    disp('*** LOADED STEADY STATE ***');
end

%% Run Dynare Analysis
dynare_opts = struct();
dynare_opts.run_stoch_simul = true;
dynare_opts.run_loglin_irs = true;
dynare_opts.run_determ_irs = true;
dynare_opts.run_determ_simul = true;
dynare_opts.sector_indices = sector_indices;
dynare_opts.modorder = 1;
dynare_opts.verbose = true;
dynare_opts.ir_length = config.ir_length;

tic;
DynareResults = run_dynare_analysis(ModData, params, dynare_opts);
fprintf('Dynare analysis time: %.2f seconds.\n', toc);

%% Process IRFs (unified for all modes)
ir_opts = struct();
ir_opts.plot_graphs = ~config.compute_all_sectors;  % Plot only for few sectors
ir_opts.save_graphs = config.save_results;
ir_opts.save_intermediate = config.save_results && config.compute_all_sectors;
ir_opts.save_interval = 5;
ir_opts.output_folder = 'output';
ir_opts.save_label = save_label;
ir_opts.ir_length = config.ir_length;

IRFResults = process_sector_irs(DynareResults, params, ModData, labels, ir_opts);

%% Build ModelData structure
ModelData = struct();

% Metadata
ModelData.metadata.date = config.date;
ModelData.metadata.exp_label = config.exp_label;
ModelData.metadata.save_label = save_label;
ModelData.metadata.sector_indices = sector_indices;
ModelData.metadata.sector_labels = labels.sector_labels;

% Calibration
ModelData.calibration = calib_data;
ModelData.params = params;

% Steady State
ModelData.SteadyState.parameters = ModData.parameters;
ModelData.SteadyState.policies_ss = ModData.policies_ss;
ModelData.SteadyState.endostates_ss = ModData.endostates_ss;
ModelData.SteadyState.Cagg_ss = ModData.Cagg_ss;
ModelData.SteadyState.Lagg_ss = ModData.Lagg_ss;
ModelData.SteadyState.Yagg_ss = ModData.Yagg_ss;
ModelData.SteadyState.Iagg_ss = ModData.Iagg_ss;
ModelData.SteadyState.Magg_ss = ModData.Magg_ss;
ModelData.SteadyState.V_ss = ModData.V_ss;

% Solution
if isfield(DynareResults, 'SolData')
    ModelData.Solution.StateSpace.A = DynareResults.SolData.A;
    ModelData.Solution.StateSpace.B = DynareResults.SolData.B;
    ModelData.Solution.StateSpace.C = DynareResults.SolData.C;
    ModelData.Solution.StateSpace.D = DynareResults.SolData.D;
    ModelData.Solution.indices = DynareResults.SolData.indices;
end
ModelData.Solution.steady_state = DynareResults.steady_state;

% IRFs
ModelData.IRFs = IRFResults;

% Simulation statistics
if isfield(DynareResults, 'SolData') && isfield(DynareResults.SolData, 'shocks_sd')
    ModelData.Simulation.shocks_sd = DynareResults.SolData.shocks_sd;
    ModelData.Simulation.states_sd = DynareResults.SolData.states_sd;
    ModelData.Simulation.policies_sd = DynareResults.SolData.policies_sd;
end

% RNG state for reproducibility
if isfield(DynareResults, 'rng_state')
    ModelData.Simulation.rng_state = DynareResults.rng_state;
end

%% Full simulation data and comparison
if isfield(DynareResults, 'SimulLoglin')
    n = params.n_sectors;
    idx = get_variable_indices(n);
    Cagg_ss = DynareResults.Cagg_ss;
    Lagg_ss = DynareResults.Lagg_ss;
    
    % Store FULL log-linear simulation data (all variables, all periods)
    ModelData.Simulation.Loglin.full_simul = DynareResults.SimulLoglin;
    ModelData.Simulation.Loglin.shocks = DynareResults.SolData.shockssim;
    ModelData.Simulation.Loglin.variable_indices = idx;
    
    % Also store aggregate time series for convenience
    Cagg_loglin = exp(DynareResults.SimulLoglin(idx.cagg, :));
    Lagg_loglin = exp(DynareResults.SimulLoglin(idx.lagg, :));
    Yagg_loglin = exp(DynareResults.SimulLoglin(idx.yagg, :));
    Iagg_loglin = exp(DynareResults.SimulLoglin(idx.iagg, :));
    Magg_loglin = exp(DynareResults.SimulLoglin(idx.magg, :));
    
    ModelData.Simulation.Loglin.Cagg = Cagg_loglin;
    ModelData.Simulation.Loglin.Lagg = Lagg_loglin;
    ModelData.Simulation.Loglin.Yagg = Yagg_loglin;
    ModelData.Simulation.Loglin.Iagg = Iagg_loglin;
    ModelData.Simulation.Loglin.Magg = Magg_loglin;
    
    % Volatility statistics
    ModelData.Simulation.Loglin.Cagg_volatility = std(Cagg_loglin)/Cagg_ss;
    ModelData.Simulation.Loglin.Lagg_volatility = std(Lagg_loglin)/Lagg_ss;
    
    fprintf('\n=== LOG-LINEAR SIMULATION STORED ===\n');
    fprintf('Simulation size: %d variables x %d periods\n', ...
        size(DynareResults.SimulLoglin, 1), size(DynareResults.SimulLoglin, 2));
    fprintf('Cagg volatility: %.4f\n', ModelData.Simulation.Loglin.Cagg_volatility);
    fprintf('Lagg volatility: %.4f\n', ModelData.Simulation.Loglin.Lagg_volatility);
end

% Deterministic simulation (if available)
if isfield(DynareResults, 'SimulDeterm') && ~isempty(DynareResults.SimulDeterm)
    n = params.n_sectors;
    idx = get_variable_indices(n);
    Cagg_ss = DynareResults.Cagg_ss;
    Lagg_ss = DynareResults.Lagg_ss;
    
    % Store FULL deterministic simulation data
    ModelData.Simulation.Determ.full_simul = DynareResults.SimulDeterm;
    if isfield(DynareResults, 'shockssim_determ')
        ModelData.Simulation.Determ.shocks = DynareResults.shockssim_determ;
    end
    
    % Aggregate time series
    Cagg_determ = exp(DynareResults.SimulDeterm(idx.cagg, :));
    Lagg_determ = exp(DynareResults.SimulDeterm(idx.lagg, :));
    
    ModelData.Simulation.Determ.Cagg = Cagg_determ;
    ModelData.Simulation.Determ.Lagg = Lagg_determ;
    ModelData.Simulation.Determ.Cagg_volatility = std(Cagg_determ)/Cagg_ss;
    ModelData.Simulation.Determ.Lagg_volatility = std(Lagg_determ)/Lagg_ss;
    
    fprintf('\n=== DETERMINISTIC SIMULATION STORED ===\n');
    fprintf('Simulation size: %d variables x %d periods\n', ...
        size(DynareResults.SimulDeterm, 1), size(DynareResults.SimulDeterm, 2));
    
    fprintf('\n=== VOLATILITY COMPARISON ===\n');
    fprintf('                     Log-Linear    Deterministic\n');
    fprintf('Cagg volatility:     %.4f        %.4f\n', ...
        ModelData.Simulation.Loglin.Cagg_volatility, ...
        ModelData.Simulation.Determ.Cagg_volatility);
    fprintf('Lagg volatility:     %.4f        %.4f\n', ...
        ModelData.Simulation.Loglin.Lagg_volatility, ...
        ModelData.Simulation.Determ.Lagg_volatility);
end

%% Save results
if config.save_results
    filename = fullfile('output', ['ModelData_' save_label '.mat']);
    save(filename, 'ModelData');
    disp(['*** SAVED: ' filename ' ***']);
end

disp('*** ANALYSIS COMPLETE ***');
