function labels = SectorLabel(indices)
% SECTORLABEL Returns BEA sector labels for given indices
%
% INPUTS:
%   indices - Vector of sector indices (1-37)
%
% OUTPUTS:
%   labels - Cell array of sector label strings
%
% The 37 sectors correspond to BEA industry classifications.

    sector_names = {
        'Mining, Oil and Gas';    % 1
        'Utilities';              % 2
        'Construction';           % 3
        'Wood';                   % 4
        'Minerals';               % 5
        'Primary Metals';         % 6
        'Fabricated Metals';      % 7
        'Machinery';              % 8
        'Computers';              % 9
        'Electrical';             % 10
        'Vehicles';               % 11
        'Transport';              % 12
        'Furniture';              % 13
        'Misc Mfg';               % 14
        'Food Mfg';               % 15
        'Textile';                % 16
        'Apparel';                % 17
        'Paper';                  % 18
        'Printing';               % 19
        'Petroleum';              % 20
        'Chemical';               % 21
        'Plastics';               % 22
        'Wholesale Trade';        % 23
        'Retail';                 % 24
        'Transp. and Wareh.';     % 25
        'Info';                   % 26
        'Finance';                % 27
        'Real estate';            % 28
        'Prof/Tech';              % 29
        'Mgmt';                   % 30
        'Admin';                  % 31
        'Educ';                   % 32
        'Health';                 % 33
        'Arts';                   % 34
        'Accom';                  % 35
        'Food Services';          % 36
        'Other';                  % 37
    };
    
    % Validate indices
    if any(indices < 1) || any(indices > 37)
        error('SectorLabel:InvalidIndex', 'Sector indices must be between 1 and 37');
    end
    
    labels = sector_names(indices);
end

